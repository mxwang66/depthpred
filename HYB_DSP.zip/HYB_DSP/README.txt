Training and validation
------------------------
To run Leanve-One-Class-Out(LOCO) on DNA strand displacement and hybridization datasets with our default model, use the command (inside "HYB_DSP" folder):
	bash HYB_DSP.sh
The whole training process would take about 20 hours. Comment out lines in "src/HYB_DSP.sh" and change "n_fold" in "read_result_HYB_DSP.py" for running fewer folds. 

Results
------------------------
The results would be saved in folder "logs", with "pred_DSP.csv" or "pred_HYB.csv" showing observed (first column) and predicted (second column) log10(rate constant) of all the validation sets combined (stop epoch = 750). "test_loss.csv" or "train_loss.csv" shows the loss of validation sets or train sets, with each column corresponding to one fold and each row corresponding to one epoch. 

Feature generation
------------------------
For features calculated with NUPACK (open probability, free energy), the NUPACK parameters are: material = DNA, temperature = according to different experiment conditions (28c/37c/46c/55c), sodium = 0.75M. 
