#!/bin/bash
cd src
bash HYB_DSP.sh
cd ..
python read_result_HYB_DSP.py
