#!/bin/bash
cd src
bash Yuan.sh
cd ..
python read_result_Yuan.py
