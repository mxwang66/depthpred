#!/bin/bash
cd src
bash Peng.sh
cd ..
python read_result_Peng.py
